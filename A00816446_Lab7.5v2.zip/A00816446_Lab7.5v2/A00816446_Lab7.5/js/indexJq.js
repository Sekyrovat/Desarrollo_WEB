$('#register').on("click", function(event){
	event.preventDefault();
	window.location.replace("./register.html");
});

$('#login').on("click", function(event){
	event.preventDefault();
	window.location.replace("./login.html");
});
