<?php
	header('Content-type: application/json');
	header('Accept: application/json');

	$servername = "localhost";
	$serverUserName = "root";
	$serverPassword = "root";
	$databaseName = "TestDB";

	$connection = new mysqli($servername, $serverUserName, $serverPassword, $databaseName);

	if ($connection->connect_error)
	{
		header("HTTP/1.1 500 Bad connection, portal is down");
		die("The server is down, we couldn't retrieve data from the data base");
	}
	else
	{

		$uName = $_GET["username"];
		#if($_SERVER['REQUEST_METHOD'] == 'GET') 
		#{
			#parse_str($_SERVER['QUERY_STRING'], $getVariables);
			#$uName = $getVariables["username"];

			#parse_str(file_get_contents("php://input"),$post_vars);
    		#echo $post_vars['username']." is the fruit\n";
			$uPassword = $_GET["password"];

			$sql = "SELECT fName, lName
					FROM Users
					WHERE username='$uName' AND passwrd='$uPassword'";
				
			$result = $connection->query($sql);

			if ($result->num_rows > 0)
			{
				
				while ($row = $result->fetch_assoc())
				{
					$response = array("firstName" => $row["fName"], "lastname" => $row["lName"]);
				}
				echo json_encode($response);
			}
			else
			{
				header("HTTP/1.1 406 User not found");
				die("Wrong credentials provided");
			} 
		#}
	}

?>










